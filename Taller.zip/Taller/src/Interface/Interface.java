
package Interface;


public interface Interface {
    
    void Lectura();
    void Logica();
}
