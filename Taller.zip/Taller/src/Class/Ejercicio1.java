
package Class;


public class Ejercicio1 extends Class{

    @Override
    public void Logica() {
        if(this.getNum()>5){
            System.out.println("El real es mayor a 5.");
        }else{
            System.out.println("El real es menor a 5.");
        }
    }
    
}
