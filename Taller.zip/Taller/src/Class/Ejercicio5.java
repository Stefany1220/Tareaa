
package Class;


public class Ejercicio5 extends Class{

    @Override
    public void Logica() {
        if(this.getNum()<200){
            System.out.println("El real es menor a 200.");
        }else{
            System.out.println("El real es mayor a 200.");
        }
    }
    
}
