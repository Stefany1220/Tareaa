
package Class;


public class Ejercicio7 extends Class{

    @Override
    public void Logica() {
       if(this.getNum()%2==0){
           System.out.println("El real es par.");
       }else{
           System.out.println("El real es impar.");
       }
    }
    
}
